package com.karthik;

public class Examm<numb, name> {


    String reverse(String s)
    {
        int len = s.length();
        String temp = " ";
        for(int i = len - 1; i >=0; i--)
        {
            temp += s.charAt(i);
        }

        return temp;

    }

    public void replaceString() {
        String org = "the dog jumped the fence";
        String[] temp = org.split(" ");
        int len = temp.length;
        String ne = "";
        for (int i = 0; i < len; i++) {
            if (temp[i].matches("the dog jumped the fence"))
                temp[i] = "that dog jumped that fence";
            ne = ne + temp[i] + " ";

        }
        System.out.println(ne);
    }

    //public class Replace {
    //}
    //public void Replace<>{

        //String str = "the dog jumped over the fence ";


      //  String replacedStr = str.replaceAll("the dog jumped over the fence", "that dog jumped over that fence");


    //}



    public void initials(String String name;
            name){

        if (0 == name.length()) {
            return;
        }


        System.out.print(Character.toUpperCase(
                name.charAt(0)));
        for (int i = 1; i < name.length() - 1; i++)
            if (name.charAt(i) == ' ')
                System.out.print(" " + Character.toUpperCase(
                        name.charAt(i + 1)));
    }





}





















