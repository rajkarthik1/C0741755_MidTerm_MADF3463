package com.karthik;

public class LambtonStringTools<str, replacedStr> {

    public static void main(String[] args) {

        String s = "Lambton";


        Examm examm = new Examm();


        System.out.println(examm.reverse("Lambton"));

       // String d;
        //d = "the dog jumped the fence";
        //public static class Replace {
        //}

        //Replace replace = new Replace();



     //   System.out.println(str, replacedStr);
    //};



}




